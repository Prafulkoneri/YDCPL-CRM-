import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';

class PrimaryAppBar extends StatelessWidget {
  final Widget? title;
  final Widget? action;
  final bool? isBackButtonEnabled;
  final bool? isProfileIconEnabled;
  final EdgeInsets? titlePadding;
  void Function()? onActionTap;
  final void Function()? onBackBtnPressed;
  final void Function()?
      onProfileIconPressed; // Function to handle profile icon tap

  PrimaryAppBar({
    Key? key,
    this.isBackButtonEnabled,
    this.isProfileIconEnabled,
    required this.title,
    this.onBackBtnPressed,
    this.onProfileIconPressed, // Receive the function here
    this.action,
    this.titlePadding,
    this.onActionTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      titleSpacing: 0,
      elevation: 0,
      systemOverlayStyle: SystemUiOverlayStyle.dark,
      toolbarHeight: 65.w,
      leading: (isBackButtonEnabled ?? true)
          ? IconButton(
              icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
              onPressed: onBackBtnPressed,
            )
          : (isProfileIconEnabled ?? false)
              ? IconButton(
                  icon: SvgPicture.asset(
                    'assets/icons/userprofile.svg',
                  ),
                  onPressed: onProfileIconPressed)
              : null,
      title: Container(
        // color: Colors.amberAccent,
        padding: titlePadding,
        child: title,
      ),
      centerTitle: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(0),
          bottom: Radius.circular(20),
        ),
      ),
      flexibleSpace: Container(
        decoration: BoxDecoration(
          borderRadius:
              const BorderRadius.vertical(bottom: Radius.circular(20)),
          gradient: LinearGradient(
            end: Alignment.centerRight,
            begin: Alignment.centerLeft,
            colors: <Color>[
              Color(0xffC5EAFF),
              Color(0xffFFFFFF),
            ],
          ),
        ),
      ),
      actions: <Widget>[
        GestureDetector(
          onTap: onActionTap,
          child: Container(
            color: Colors.transparent,
            height: 100.w,
            width: 100.w,
            child: Align(
              alignment: Alignment.centerRight,
              child: Padding(
                padding: const EdgeInsets.only(right: 20.0),
                child: action,
              ),
            ),
          ),
        )
      ],
    );
  }
}
