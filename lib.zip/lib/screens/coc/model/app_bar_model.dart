class AppBarResponseMiodel {
  String? status;
  String? message;
  AppBarImage? appBar;

  AppBarResponseMiodel({
    required this.status,
    required this.message,
    required this.appBar,
  });
  AppBarResponseMiodel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    appBar = json['data'] != null ? AppBarImage.fromJson(json['data']) : null;
  }
}

class AppBarImage {
  String? imageAppBar;

  AppBarImage({
    required this.imageAppBar,
  });
  AppBarImage.fromJson(Map<String, dynamic> json) {
    imageAppBar = json["app_bar_image"];
  }
}
