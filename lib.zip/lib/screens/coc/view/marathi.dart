import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:ydcpl_application/screens/bottom_navigation/view/bottom_view.dart';
import 'package:ydcpl_application/screens/coc/controller/coc_controller.dart';
import 'package:ydcpl_application/screens/coc/view/hindi_coc.dart';
import 'package:ydcpl_application/screens/home/view/home_view.dart';
import 'package:ydcpl_application/utils/utils.dart';
import 'package:ydcpl_application/widgets/buttons.dart';

class MarathicocScreenView extends StatefulWidget {
  const MarathicocScreenView({Key? key}) : super(key: key);

  @override
  State<MarathicocScreenView> createState() => _MarathicocScreenViewState();
}

class _MarathicocScreenViewState extends State<MarathicocScreenView> {
  @override
  void initState() {
    SchedulerBinding.instance.addPostFrameCallback((_) {
      context.read<CocViewController>().initState(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    final watch = context.watch<CocViewController>();
    final read = context.read<CocViewController>();
    return Scaffold(
      body: Column(
        children: [
          Stack(
            children: [
              Image(image: AssetImage("assets/images/appb.png")),
              Positioned(
                right: 0.w,
                left: 0,
                bottom: 20.w,
                child: Image(
                  image: NetworkImage('${watch.appBar?.imageAppBar ?? ''}'),
                  height: 20.h,
                ),
              )
            ],
          ),
          Container(
            padding: EdgeInsets.all(20.w),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => HindicocScreenView()),
                      );
                    },
                    child: SvgPicture.asset(
                      'assets/icons/backword.svg',
                      color: Color.fromARGB(255, 3, 18, 228),
                    )),
                Text(
                  "Marathi",
                  style: GoogleFonts.inter(
                    textStyle: TextStyle(
                        color: Color(0xff413185),
                        letterSpacing: .5,
                        fontSize: 15.sp,
                        fontWeight: FontWeight.w500),
                  ),
                ),
                SvgPicture.asset('assets/icons/forword.svg',
                    color: Colors.grey),
              ],
            ),
          ),
          Divider(
            indent: 15.w,
            endIndent: 15.w,
            thickness: 2,
            color: Color(0xffE3F5FF),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(15.w),
              child: RawScrollbar(
                thickness: 2.w,
                thumbColor: Colors.blue,
                child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  physics: const BouncingScrollPhysics(),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: [
                        // Text(
                        //   "कोणत्याही प्रकारच्या त्रुटीसाठी क्षमस्वून घ्या. येथे तुम्हाला एक उदाहरण पहायला मिळतील. हे मराठीतून पाठ आहे.",
                        //   style: GoogleFonts.notoSans(
                        //     textStyle: TextStyle(
                        //       fontSize: 16.sp,
                        //     ),
                        //   ),
                        // ),
                        // Text(
                        //   "कोणत्याही प्रकारच्या त्रुटीसाठी क्षमस्वून घ्या. येथे तुम्हाला एक उदाहरण पहायला मिळतील. हे मराठीतून पाठ आहे.",
                        //   style: GoogleFonts.notoSans(
                        //     textStyle: TextStyle(
                        //       fontSize: 16.sp,
                        //     ),
                        //   ),
                        // ),
                        // Text(
                        //   "कोणत्याही प्रकारच्या त्रुटीसाठी क्षमस्वून घ्या. येथे तुम्हाला एक उदाहरण पहायला मिळतील. हे मराठीतून पाठ आहे.",
                        //   style: GoogleFonts.notoSans(
                        //     textStyle: TextStyle(
                        //       fontSize: 16.sp,
                        //     ),
                        //   ),
                        // ),
                        // Text(
                        //   "कोणत्याही प्रकारच्या त्रुटीसाठी क्षमस्वून घ्या. येथे तुम्हाला एक उदाहरण पहायला मिळतील. हे मराठीतून पाठ आहे.",
                        //   style: GoogleFonts.notoSans(
                        //     textStyle: TextStyle(
                        //       fontSize: 16.sp,
                        //     ),
                        //   ),
                        // ),
                        // Text(
                        //   "कोणत्याही प्रकारच्या त्रुटीसाठी क्षमस्वून घ्या. येथे तुम्हाला एक उदाहरण पहायला मिळतील. हे मराठीतून पाठ आहे.",
                        //   style: GoogleFonts.notoSans(
                        //     textStyle: TextStyle(
                        //       fontSize: 16.sp,
                        //     ),
                        //   ),
                        // ),
                        HtmlWidget(watch.htmlContentMarathi),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.only(
                left: 19.w, top: 25.w, bottom: 42.w, right: 16.w),
            // height: 100,
            color: Color(0xffE7F6FF),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    GestureDetector(
                        onTap: () {
                          read.onChecked();
                        },
                        child: watch.isChecked
                            ? SvgPicture.asset(
                                'assets/icons/ion_checkbox.svg',
                                // width: 20.w,
                                // height: 18.h,
                              )
                            : Container(
                                margin:
                                    EdgeInsets.only(right: 5.w, bottom: 2.5.w),
                                height: 20.h,
                                width: 20.w,
                                decoration: BoxDecoration(
                                    color:
                                        //  watch.isChecked
                                        //     ? Colors.blue
                                        //     :
                                        const Color(0xffD9D9D9),
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(2))),
                              )),
                    Text(
                      "Agree to COC ",
                      style: GoogleFonts.inter(
                        textStyle: TextStyle(
                            color: Color(0xff1B1B1B),
                            letterSpacing: .5,
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
                // PrimaryButton(
                //   width: 150.w,
                //   height: 45.w,
                //   color: Color(0xff413185),
                //   onTap: () {
                //     Navigator.pushReplacement(
                //       context,
                //       MaterialPageRoute(
                //           builder: (context) => const MainScreenView(
                //               index: 0,
                //               screenName: HomePageScreenView(
                //                   // refreshPage: true,
                //                   ))),
                //       // (Route<dynamic> route) => false,
                //     );
                //   },
                //   child: Text(
                //     "Submit",
                //     style: GoogleFonts.inter(
                //       textStyle: TextStyle(
                //           color: Colors.white,
                //           letterSpacing: .5,
                //           fontSize: 16.sp,
                //           fontWeight: FontWeight.w600),
                //     ),
                //   ),
                // )
                PrimaryButton(
                  width: 150.w,
                  height: 45.w,
                  color: Color(0xff413185),
                  onTap: watch.isChecked
                      ? () {
                          print("object");
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const MainScreenView(
                                index: 2,
                                screenName: HomePageScreenView(),
                              ),
                            ),
                          );
                        }
                      : () {
                          Utils.showPrimarySnackbar(
                              context, ' Please agree to the COC',
                              type: SnackType.error);
                        },
                  child: Text(
                    "Submit",
                    style: GoogleFonts.inter(
                      textStyle: TextStyle(
                        color: Colors.white,
                        letterSpacing: .5,
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
